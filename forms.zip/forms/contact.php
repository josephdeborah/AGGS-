 <?php
use PHPMailer\PHPMailer\Exception;
use PHPMailer\PHPMailer\PHPMailer;
require 'PHPMailer-master\src\Exception.php';
require 'PHPMailer-master\src\PHPMailer.php';
require 'PHPMailer-master\src\SMTP.php';
$mail = new PHPMailer(true);
if (isset( $_POST['message'] )) {
  try {
  $mail->isSMTP();
  $mail->Host='smtp.gmail.com';
  $mail->SMTPAuth=true;
  $mail->Username='devdeb2024@gmail.com';
  $mail->Password='aoxfmivnjbhrvwzn';
  $mail->SMTPSecure='tls';
  $mail->Port='587';
  $mail->setFrom('devdeb2024@gmail.com' , "Anglican Girls' Grammar School");
  $mail->addAddress($_POST['email']);
  $mail->isHTML(true);
  $mail->Subject= $_POST['subject'];
  $mail->Body= $_POST['message'] ; 
  $mail->send();
  $mailSent=  $mail->send();
  if( $mailSent){
  echo $sent="message sent";
    
  }
 
} catch (Exception  ) {
  echo $Error=$mail->ErrorInfo;
  
}

} else {

  die('unable to connect to our server');
}


  /**
  * Requires the "PHP Email Form" library
  * The "PHP Email Form" library is available only in the pro version of the template
  * The library should be uploaded to: vendor/php-email-form/php-email-form.php
  * For more info and help: https://bootstrapmade.com/php-email-form/
  */

  // Replace contact@example.com with your real receiving email address
//   $receiving_email_address = 'josepholubukunola@gmail.com';

//   // if( file_exists($php_email_form = '../assets/vendor/php-email-form/php-email-form.php' )) {
//   //   include( $php_email_form );
//   // } else {
//   //   die( 'Unable to load the "PHP Email Form" Library!');
//   // }

//   $contact = new PHPMailer(true);
//   // $contact->ajax = true;
  
//   $contact->to = $receiving_email_address;
//   $contact->from_name = $_POST['name'];
//   $contact->from_email = $_POST['email'];
//   $contact->subject = $_POST['subject'];

//   // Uncomment below code if you want to use SMTP to send emails. You need to enter your correct SMTP credentials
//   /*
//   $contact->smtp = array(
//     'host' => 'example.com',
//     'username' => 'example',
//     'password' => 'pass',
//     'port' => '587'
//   );
//   */

//   $contact->add_message( $_POST['name'], 'From');
//   $contact->add_message( $_POST['email'], 'Email');
//   if(isset($_POST['phone'])) {
//     $contact->add_message( $_POST['phone'], 'Phone');
//   }
//   $contact->add_message( $_POST['message'], 'Message', 10);

//   echo $contact->send();
 ?>
